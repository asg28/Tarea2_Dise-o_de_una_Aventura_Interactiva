package com.example.newyork_tarea2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // 1. OBTENER REFERENCIAS A LOS TRES BOTONES
        val centralParkButton: ImageButton = findViewById(R.id.btn_central_park)
        // **¡NUEVO!** Referencia para Empire State
        val empireStateButton: ImageButton = findViewById(R.id.btn_empire_state)
        // **¡NUEVO!** Referencia para el tercer Hotspot
        val hotspot3Button: ImageButton = findViewById(R.id.btn_regresar_mapa_liberty)

        // 2. CONFIGURAR LISTENERS PARA CADA BOTÓN

        // Listener 1: Central Park
        centralParkButton.setOnClickListener {
            val intent = Intent(this@MainActivity, CentralParkActivity::class.java)
            startActivity(intent)
        }

        // Listener 2: Empire State **(¡Este faltaba!)**
        empireStateButton.setOnClickListener {
            // Usa el nombre exacto de la Activity del Empire State
            val intent = Intent(this@MainActivity, EmpireStateActivity::class.java)
            startActivity(intent)
        }

        // Listener 3: Tercer Hotspot (Ahora Estatua de la Libertad)
        hotspot3Button.setOnClickListener {
            // ¡Lanza la nueva Activity de la Estatua de la Libertad!
            val intent = Intent(this@MainActivity, LibertyActivity::class.java)
            startActivity(intent)
        }
    }
}