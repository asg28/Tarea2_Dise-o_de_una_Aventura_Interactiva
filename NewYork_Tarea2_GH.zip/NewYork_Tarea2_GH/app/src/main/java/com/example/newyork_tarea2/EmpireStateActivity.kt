package com.example.newyork_tarea2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class EmpireStateActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_empire_state)

        // Cargar el fragment la primera vez
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerEmpire, EmpireStateFragment())
                .commit()
        }
    }
}
