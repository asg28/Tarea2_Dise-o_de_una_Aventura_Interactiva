package com.example.newyork_tarea2

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class LibertyFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View? {
        // Inflamos el layout del fragmento
        return inflater.inflate(R.layout.fragment_liberty, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // --- Lógica de Puntos de Interés (POI) ---
        val poiCrown = view.findViewById<LinearLayout>(R.id.poiCrown)
        val poiMuseum = view.findViewById<LinearLayout>(R.id.poiMuseum)
        val poiHistory = view.findViewById<LinearLayout>(R.id.poiHistory)

        poiCrown.setOnClickListener {
            showPoiDialog("Corona y Mirador",
                "Se requieren reservas anticipadas. Ofrece una vista panorámica única.",
                R.drawable.liberty_crown) // Debes crear este recurso
        }

        poiMuseum.setOnClickListener {
            showPoiDialog("Museo de la Isla",
                "Ubicado en la base, detalla la historia del monumento y su significado.",
                R.drawable.liberty_museum) // Debes crear este recurso
        }

        poiHistory.setOnClickListener {
            showPoiDialog("Regalo de Francia",
                "La estatua fue un regalo del pueblo francés a Estados Unidos.",
                R.drawable.liberty_history) // Debes crear este recurso
        }

        // --- Lógica del Botón de Regreso ---
        val returnButton = view.findViewById<Button>(R.id.btn_regresar_mapa_liberty)

        returnButton.setOnClickListener {
            // Cierra la Activity actual y regresa a MainActivity
            activity?.finish()
        }
    }

    private fun showPoiDialog(title: String, desc: String, imageRes: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_poi, null)
        val img = dialogView.findViewById<ImageView>(R.id.dlgImage)
        val descTv = dialogView.findViewById<TextView>(R.id.dlgDesc)
        img.setImageResource(imageRes)
        descTv.text = desc

        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Cerrar", null)
            .show()
    }
}