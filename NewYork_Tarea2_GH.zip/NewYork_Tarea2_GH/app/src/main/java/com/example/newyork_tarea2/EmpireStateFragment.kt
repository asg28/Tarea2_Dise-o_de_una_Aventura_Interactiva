package com.example.newyork_tarea2

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class EmpireStateFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View? {
        // Inflamos el layout del fragmento
        return inflater.inflate(R.layout.fragment_empire_state, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // --- Lógica de Puntos de Interés (POI) ---
        val poiObservation = view.findViewById<LinearLayout>(R.id.poiObservation)
        val poiLobby = view.findViewById<LinearLayout>(R.id.poiLobby)
        val poiHistory = view.findViewById<LinearLayout>(R.id.poiHistory)

        poiObservation.setOnClickListener {
            showPoiDialog("Observation Deck",
                "El mirador ofrece vistas 360° de Manhattan. Recomendado al atardecer.",
                R.drawable.empire_observation)
        }

        poiLobby.setOnClickListener {
            showPoiDialog("Lobby y arquitectura",
                "El lobby conserva detalles art déco originales y exhibiciones.",
                R.drawable.empire_lobby)
        }

        poiHistory.setOnClickListener {
            showPoiDialog("Historia",
                "Construido en 1931, fue el edificio más alto del mundo por décadas.",
                R.drawable.empire_history)
        }

        // --- Lógica del Botón de Regreso (Nuevo) ---
        val returnButton = view.findViewById<Button>(R.id.btn_regresar_mapa)

        returnButton.setOnClickListener {
            // El método 'finish()' termina la Activity que contiene este Fragmento
            // y regresa a la Activity anterior en la pila (el mapa principal).
            activity?.finish()
        }
    }

    private fun showPoiDialog(title: String, desc: String, imageRes: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_poi, null)
        val img = dialogView.findViewById<ImageView>(R.id.dlgImage)
        val descTv = dialogView.findViewById<TextView>(R.id.dlgDesc)
        img.setImageResource(imageRes)
        descTv.text = desc

        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Cerrar", null)
            .show()
    }
}