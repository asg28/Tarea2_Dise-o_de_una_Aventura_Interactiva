package com.example.newyork_tarea2

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class CentralPerkFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_central_perk, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // --- Lógica de Puntos de Interés (POI) ---
        // Debes asegurarte de tener estas referencias en el XML
        val poiTheMall = view.findViewById<LinearLayout>(R.id.poiTheMall)
        val poiStrawberryFields = view.findViewById<LinearLayout>(R.id.poiStrawberryFields)
        val poiBethesda = view.findViewById<LinearLayout>(R.id.poiBethesda)

        // Lógica del botón de regreso
        val returnButton: Button = view.findViewById(R.id.btn_regresar)
        returnButton.setOnClickListener {
            activity?.finish()
        }

        // Configurar Listeners para los POI
        poiTheMall.setOnClickListener {
            showPoiDialog("The Mall",
                "Famoso paseo bordeado de olmos americanos, lleva al Terrace y es conocido por sus estatuas literarias.",
                R.drawable.central_perk_themall) // Usa tu propio drawable para The Mall
        }

        poiStrawberryFields.setOnClickListener {
            showPoiDialog("Strawberry Fields",
                "Un jardín conmemorativo dedicado a la memoria de John Lennon, cerca de su residencia, el Edificio Dakota.",
                R.drawable.central_perk_strawberry) // Usa tu propio drawable para Strawberry Fields
        }

        poiBethesda.setOnClickListener {
            showPoiDialog("Bethesda Terrace",
                "El corazón del parque, famoso por su arquitectura y la Fuente del Ángel de las Aguas.",
                R.drawable.central_perk_bethesda) // Usa tu propio drawable para Bethesda
        }
    }

    // Método reutilizado para mostrar el diálogo de detalle del POI
    private fun showPoiDialog(title: String, desc: String, imageRes: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_poi, null)
        val img = dialogView.findViewById<ImageView>(R.id.dlgImage)
        val descTv = dialogView.findViewById<TextView>(R.id.dlgDesc)
        img.setImageResource(imageRes)
        descTv.text = desc

        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Cerrar", null)
            .show()
    }
}