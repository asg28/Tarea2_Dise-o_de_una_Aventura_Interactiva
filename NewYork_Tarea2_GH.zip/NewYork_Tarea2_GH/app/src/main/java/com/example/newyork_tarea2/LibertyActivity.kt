package com.example.newyork_tarea2

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity // 1. Debe heredar de AppCompatActivity
import com.example.newyork_tarea2.LibertyFragment // 2. ¡IMPORTACIÓN FALTANTE!

class LibertyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_liberty)

        // Esto ahora funcionará si el Fragmento existe y está importado
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.liberty_fragment_container, LibertyFragment())
                .commit()
        }
    }
}